import torch

# 测试python环境是否正常,输出123则正常
print(123)
# 测试pyTorch环境是否正常,输出True则正常
print(torch.cuda.is_available())
