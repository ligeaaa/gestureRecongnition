此仓库用于存储团队项目python相关代码

将个人的开发经历记录在[博客](http://www.magic-knowledge.top/2023/11/15/%e6%89%8b%e5%8a%bf%e8%af%86%e5%88%ab%e9%a1%b9%e7%9b%ae%e9%95%bf%e6%9c%9f%e8%ae%b0%e5%bd%95/)中

cnn文件夹中是使用传统cnn模型跑，在100轮训练后的正确率为55%